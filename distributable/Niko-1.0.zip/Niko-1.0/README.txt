
Installation von Niko:

	Windows:
	1. install.bat ausführen (Doppelklick)
	
	Mac/Linux:
	1. install.sh ausführen (Doppelklick)