from os.path import dirname, realpath


__all__ = ["roboter"]

RESOURCE_PFAD = dirname(realpath(__file__))+"\\resources\\"
